(function($) {
    'use strict';

    $(document).ready(function($) {



    }); //end DOM ready

})(jQuery);